namespace Cukraszda_WFA
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            fajlToolStripMenuItem = new ToolStripMenuItem();
            megnyitasToolStripMenuItem = new ToolStripMenuItem();
            toolStripSeparator1 = new ToolStripSeparator();
            kilepesToolStripMenuItem = new ToolStripMenuItem();
            sutemenyekToolStripMenuItem = new ToolStripMenuItem();
            nevjegyToolStripMenuItem = new ToolStripMenuItem();
            pictureBox1 = new PictureBox();
            menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            //
            // menuStrip1
            //
            menuStrip1.Items.AddRange(new ToolStripItem[] { fajlToolStripMenuItem, sutemenyekToolStripMenuItem, nevjegyToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(434, 24);
            menuStrip1.TabIndex = 0;
            //
            // fajlToolStripMenuItem
            //
            fajlToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { megnyitasToolStripMenuItem, toolStripSeparator1, kilepesToolStripMenuItem });
            fajlToolStripMenuItem.Name = "fajlToolStripMenuItem";
            fajlToolStripMenuItem.Text = "Fájl";
            //
            // megnyitasToolStripMenuItem
            //
            megnyitasToolStripMenuItem.Name = "megnyitasToolStripMenuItem";
            megnyitasToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.O;
            megnyitasToolStripMenuItem.Text = "Megnyitás...";
            megnyitasToolStripMenuItem.Click += megnyitasToolStripMenuItem_Click;
            //
            // kilepesToolStripMenuItem
            //
            kilepesToolStripMenuItem.Name = "kilepesToolStripMenuItem";
            kilepesToolStripMenuItem.Text = "Kilépés";
            kilepesToolStripMenuItem.Click += kilepesToolStripMenuItem_Click;
            //
            // sutemenyekToolStripMenuItem
            //
            sutemenyekToolStripMenuItem.Name = "sutemenyekToolStripMenuItem";
            sutemenyekToolStripMenuItem.Text = "sutemenyek";
            sutemenyekToolStripMenuItem.Click += sutemenyekToolStripMenuItem_Click;
            //
            // nevjegyToolStripMenuItem
            //
            nevjegyToolStripMenuItem.Name = "nevjegyToolStripMenuItem";
            nevjegyToolStripMenuItem.Text = "Névjegy";
            nevjegyToolStripMenuItem.Click += nevjegyToolStripMenuItem_Click;
            //
            // pictureBox1
            //
            pictureBox1.Location = new Point(30, 45);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(370, 300);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            //
            // Form1
            //
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(434, 371);
            Controls.Add(pictureBox1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Cukrászda";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem fajlToolStripMenuItem;
        private ToolStripMenuItem megnyitasToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator1;
        private ToolStripMenuItem kilepesToolStripMenuItem;
        private ToolStripMenuItem sutemenyekToolStripMenuItem;
        private ToolStripMenuItem nevjegyToolStripMenuItem;
        private PictureBox pictureBox1;
    }
}
