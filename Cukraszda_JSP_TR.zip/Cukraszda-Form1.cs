using System.Text;

namespace Cukraszda_WFA
{
    public partial class Form1 : Form
    {
        private readonly List<Sutemeny> sutemenyek = new List<Sutemeny>();
        private ArlistaForm arlistaForm;

        public Form1()
        {
            InitializeComponent();
            sutemenyekToolStripMenuItem.Enabled = false;   // csak fájlbetöltés után
            // TODO: kép betöltése a pictureBox1-be
        }

        private void megnyitasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using OpenFileDialog ofd = new OpenFileDialog
            {
                Title = "Sütemények adatfájl megnyitása",
                Filter = "Szöveges fájl (*.txt)|*.txt|Minden fájl (*.*)|*.*"
            };
            if (ofd.ShowDialog() != DialogResult.OK) return;

            sutemenyek.Clear();
            foreach (string sor in File.ReadAllLines(ofd.FileName, Encoding.UTF8))
            {
                if (string.IsNullOrWhiteSpace(sor)) continue;
                sutemenyek.Add(Sutemeny.Feldolgoz(sor));
            }
            // TODO: hibás fájl kezelése (try-catch)

            sutemenyekToolStripMenuItem.Enabled = true;
            ArlistaMegjelenit();
        }

        private void sutemenyekToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ArlistaMegjelenit();
        }

        private void ArlistaMegjelenit()
        {
            if (arlistaForm == null || arlistaForm.IsDisposed)
            {
                arlistaForm = new ArlistaForm(sutemenyek);
                arlistaForm.Show(this);
            }
            else
            {
                arlistaForm.Activate();
            }
        }

        private void kilepesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void nevjegyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // TODO: névjegy
        }
    }
}
