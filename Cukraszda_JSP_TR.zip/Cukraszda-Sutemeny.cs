namespace Cukraszda_WFA
{
    /// <summary>Egy sütemény a választékból (név + egységár).</summary>
    public class Sutemeny
    {
        public string Nev { get; }
        public int Ar { get; }

        public Sutemeny(string nev, int ar)
        {
            Nev = nev;
            Ar = ar;
        }

        /// <summary>Egy "Név;Ár" formátumú sor feldolgozása.</summary>
        public static Sutemeny Feldolgoz(string sor)
        {
            string[] r = sor.Split(';');
            return new Sutemeny(r[0].Trim(), int.Parse(r[1].Trim()));
        }

        public override string ToString() => $"{Nev}({Ar} Ft)";
    }

    /// <summary>A rendelés egy tétele.</summary>
    public class RendelesTetel
    {
        public Sutemeny Sutemeny { get; }
        public int Adag { get; }
        public int Osszeg => Sutemeny.Ar * Adag;

        public RendelesTetel(Sutemeny sutemeny, int adag)
        {
            Sutemeny = sutemeny;
            Adag = adag;
        }
    }
}
