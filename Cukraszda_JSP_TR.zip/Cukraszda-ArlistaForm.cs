namespace Cukraszda_WFA
{
    public partial class ArlistaForm : Form
    {
        private readonly List<Sutemeny> sutemenyek;
        private readonly List<CheckBox> jelolok = new List<CheckBox>();
        private readonly List<TextBox> adagok = new List<TextBox>();

        public ArlistaForm(List<Sutemeny> sutemenyek)
        {
            InitializeComponent();
            this.sutemenyek = sutemenyek;
            SorokLetrehozasa();
        }

        private void SorokLetrehozasa()
        {
            int y = 70;
            foreach (Sutemeny s in sutemenyek)
            {
                CheckBox cb = new CheckBox
                {
                    Text = s.ToString(),
                    Location = new Point(30, y),
                    AutoSize = true
                };
                TextBox tb = new TextBox
                {
                    Location = new Point(290, y - 2),
                    Size = new Size(40, 23)
                };
                Label lbl = new Label
                {
                    Text = "adag",
                    Location = new Point(340, y + 1),
                    AutoSize = true
                };

                Controls.Add(cb);
                Controls.Add(tb);
                Controls.Add(lbl);
                jelolok.Add(cb);
                adagok.Add(tb);
                y += 30;
            }

            btnRendel.Location = new Point(165, y + 30);
        }

        private void btnRendel_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                bool vanKijelolve = jelolok.Any(c => c.Checked);
                if (!vanKijelolve)
                {
                    MessageBox.Show("Nincs kijelölve egyetlen sütemény sem!", "Hiba",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                // TODO: rendelés összeállítása az adagokból
            }
            // TODO: jobb gomb -> context menü (számlát kér)
        }

        private void szamlatKerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // TODO: számla richTextBox-ban (SzamlaForm)
        }
    }
}
