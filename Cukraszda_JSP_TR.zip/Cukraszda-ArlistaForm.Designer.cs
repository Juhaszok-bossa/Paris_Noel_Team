namespace Cukraszda_WFA
{
    partial class ArlistaForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            lblCim = new Label();
            btnRendel = new Button();
            contextMenuStrip1 = new ContextMenuStrip(components);
            szamlatKerToolStripMenuItem = new ToolStripMenuItem();
            contextMenuStrip1.SuspendLayout();
            SuspendLayout();
            //
            // lblCim
            //
            lblCim.Font = new Font("Algerian", 20F, FontStyle.Bold | FontStyle.Italic);
            lblCim.ForeColor = Color.OrangeRed;
            lblCim.Location = new Point(0, 15);
            lblCim.Name = "lblCim";
            lblCim.Size = new Size(434, 40);
            lblCim.TabIndex = 0;
            lblCim.Text = "ÁRLISTA";
            lblCim.TextAlign = ContentAlignment.MiddleCenter;
            //
            // btnRendel
            //
            btnRendel.Location = new Point(165, 260);
            btnRendel.Name = "btnRendel";
            btnRendel.Size = new Size(100, 27);
            btnRendel.TabIndex = 1;
            btnRendel.Text = "RENDEL";
            btnRendel.UseVisualStyleBackColor = true;
            btnRendel.MouseUp += btnRendel_MouseUp;
            //
            // contextMenuStrip1
            //
            contextMenuStrip1.Items.AddRange(new ToolStripItem[] { szamlatKerToolStripMenuItem });
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new Size(140, 26);
            //
            // szamlatKerToolStripMenuItem
            //
            szamlatKerToolStripMenuItem.Name = "szamlatKerToolStripMenuItem";
            szamlatKerToolStripMenuItem.Size = new Size(139, 22);
            szamlatKerToolStripMenuItem.Text = "Számlát kér";
            szamlatKerToolStripMenuItem.Click += szamlatKerToolStripMenuItem_Click;
            //
            // ArlistaForm
            //
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(434, 320);
            Controls.Add(btnRendel);
            Controls.Add(lblCim);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "ArlistaForm";
            StartPosition = FormStartPosition.CenterParent;
            Text = "ArlistaForm";
            contextMenuStrip1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Label lblCim;
        private Button btnRendel;
        private ContextMenuStrip contextMenuStrip1;
        private ToolStripMenuItem szamlatKerToolStripMenuItem;
    }
}
